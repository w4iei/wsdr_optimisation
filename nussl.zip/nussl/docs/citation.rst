Citing nussl
------------
If you use *nussl* in any of your research, we ask that you cite
the following paper:

Manilow, Ethan, Prem Seetharaman, and Bryan Pardo.
"The Northwestern University Source Separation Library." 
ISMIR. 2018.

.. code-block::

    @inproceedings{manilow2018northwestern,
        title={The Northwestern University Source Separation Library.},
        author={Manilow, Ethan and Seetharaman, Prem and Pardo, Bryan},
        booktitle={ISMIR},
        pages={297--305},
        year={2018}
    }

Thank you!