Factorization
=============

.. toctree::
   :maxdepth: 4

   RPCA <rpca.py>
   ICA <ica.py>
