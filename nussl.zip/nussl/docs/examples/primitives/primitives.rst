Primitives
==========

.. toctree::
   :maxdepth: 4

   FT2D <2dft.py>
   REPET <repet.py>
   REPETSIM <repet_sim.py>
   Melodia <melodia.py>
   TimbreClustering <timbre.py>
   HPSS <hpss.py>
