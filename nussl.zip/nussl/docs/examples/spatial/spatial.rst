Spatial methods
===============

.. toctree::
   :maxdepth: 4

   SpatialClustering <spatial_clustering.py>
   PROJET <projet.py>
   DUET <duet.py>
