Composite methods
=================

.. toctree::
   :maxdepth: 4

   EnsembleClustering <ensemble_clustering.py>
