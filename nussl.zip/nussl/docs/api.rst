API Documentation
-----------------
.. toctree::
   :maxdepth: 1

   core
   datasets
   evaluation
   ml
   separation