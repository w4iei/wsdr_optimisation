.. _recipes:

===============
Recipes
===============

.. toctree::
    :maxdepth: 5

    WHAM! <wham/wham>
    