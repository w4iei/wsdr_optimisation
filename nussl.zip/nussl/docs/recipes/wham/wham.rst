.. _wham:

=====
WHAM!
=====

.. toctree::
    :maxdepth: 5

    Deep clustering <deep_clustering>
    Mask inference <mask_inference>
    Chimera networks <chimera>
    Ideal binary mask <ideal_binary_mask>
    Ideal ratio mask <ideal_ratio_mask>
