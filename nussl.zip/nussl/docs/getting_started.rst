.. _getting_started:

===============
Getting Started
===============

.. toctree::
    :maxdepth: 5

    Installation <tutorials/install>
    Introduction to AudioSignals <tutorials/audio_signal>
    Separation via Time-Frequency Masking <tutorials/masking_audio_signals.py>
    